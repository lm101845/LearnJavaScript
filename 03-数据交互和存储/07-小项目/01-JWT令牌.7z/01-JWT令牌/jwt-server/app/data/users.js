const users = [
  {
    id: 1,
    username: 'zhangsan',
    password: 123456,
    nickname: '张三'
  },
  {
    id: 2,
    username: 'lisi',
    password: 123456,
    nickname: '李四'
  }
]

module.exports = users