module.exports = {
  secretKey: 'jK123uu_s$!',
  expiresIn: 24 * 60 * 60
}